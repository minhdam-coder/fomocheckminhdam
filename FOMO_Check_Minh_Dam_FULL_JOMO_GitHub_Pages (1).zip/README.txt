FOMO Check Minh Đạm
Bản này GIỮ NGUYÊN giao diện JOMO 7 ngày dạng sidebar/dashboard.
Đồng thời thêm phần giới thiệu/giao diện đầu trang từ website FOMO Check cũ.

Cách dùng:
1. Giải nén ZIP.
2. Upload index.html lên repository GitHub Pages.
3. Mở bằng Chrome/Safari/Edge qua link GitHub Pages.
